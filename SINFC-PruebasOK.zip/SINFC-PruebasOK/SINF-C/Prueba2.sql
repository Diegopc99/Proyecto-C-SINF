-- Espectaculo de la vida de Bryan  en las gradas con id de 12 a 15 de Sala A a Sala D

CALL estadoLocalidades_grada(12,6); 
CALL estadoLocalidades_grada(13,6); 
CALL estadoLocalidades_grada(14,6); 
CALL estadoLocalidades_grada(15,6); 

